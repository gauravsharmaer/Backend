const Blog = require("../Schema.js");
const mongoose = require("mongoose");

//get all blogs//
const getblogs = async (req, res) => {
  const blogs = await Blog.find({}).sort({ createdAt: -1 });
  res.status(200).json(blogs);
};

//get a single blog/
const getblog = async (req, res) => {
  const { id } = req.params;
  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({ error: "no such blog" });
  }
  const blog = await Blog.findById(id);
  if (!blog) {
    return res.status(404).json({ error: "no such blog" });
  }
  res.status(200).json(blog);
};

//create new blog//
const createblog = async (req, res) => {
  const { topic, description, posted_at, posted_by } = req.body;
  try {
    const blog = await Blog.create({
      topic,
      description,
      posted_at,
      posted_by,
    });
    res.status(200).json(blog);
  } catch (error) {
    res.status(404).json({ error: "no such blog" });
  }
};

//delete a blog//
const deleteblog = async (req, res) => {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({ error: "no such blog" });
    }
    const blog = await Blog.findOneAndDelete(id);
    if (!blog) {
      return res.status(404).json({ error: "no such blog" });
    }
    res.status(200).json(blog);
  };


  //update a blog//
  const updateblog = async (req, res) => {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({ error: "no such blog" });
    }
    const blog = await Blog.findOneAndUpdate({ _id: id }, { ...req.body });
    if (!blog) {
      return res.status(404).json({ error: "no such blog" });
    }
    res.status(200).json(blog);
  };

  module.exports={updateblog,deleteblog,createblog, getblog,getblogs }