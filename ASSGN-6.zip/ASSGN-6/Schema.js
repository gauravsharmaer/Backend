const mongoose=require("mongoose");
const schema=mongoose.Schema;
const blogschema=new schema({
    topic:{
        type:String,
        require:true
    },
    description:{
        type:String,
        require:true
    },
    posted_at:{
        type:String,
        require:true
    },
    posted_by:{
        type:String,
        require:true
    }
},{timestamps:true})
module.exports=mongoose.model("blog",blogschema);

