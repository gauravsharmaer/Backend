const mongoose=require("mongoose");
const express=require("express");
const app=express();
  const Blogroutes=require("./routes/Blogroutes")

  app.use(express.json());
  app.use("/blog",Blogroutes)


  mongoose.connect("mongodb://127.0.0.1:27017/Blog")
  .then(()=>{
    app.listen(5000,()=>{
        console.log("listening on port 5000")
    })
    
  }).catch((error)=>{
    console.log(error);
  })
